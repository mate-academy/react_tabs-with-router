import React from 'react';

export const HomePage: React.FC = () => (
  <p>Home page</p>
);
