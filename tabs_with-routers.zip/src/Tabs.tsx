/* eslint-disable jsx-a11y/anchor-is-valid */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/interactive-supports-focus */
import React from 'react';
import classnames from 'classnames';

type Props = {
  tabs: Tab[],
  selectedTabId: string,
  onSelected: (tabId: string) => void,
};

export const Tabs: React.FC<Props> = ({ tabs, onSelected, selectedTabId }) => {
  return (
    <>
      <div className="tabs">
        <ul>
          {tabs.map(tab => (
            <li
              className={classnames({ 'is-active': selectedTabId === tab.id })}
              key={tab.id}
            >
              <a
                className="button"
                role="button"
                onClick={(e) => {
                  e.preventDefault();
                  if (selectedTabId !== tab.id) {
                    onSelected(tab.id);
                  }
                }}
                key={tab.id}
              >
                {tab.title}
              </a>
            </li>
          ))}
        </ul>
      </div>

      <div className="tabcontent">
        <p>
          {tabs.find(tab => tab.id === selectedTabId)?.content}
        </p>
      </div>
    </>
  );
};
