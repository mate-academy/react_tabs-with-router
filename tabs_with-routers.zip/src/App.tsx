import React from 'react';
import {
  Link,
  Routes,
  Route,
  Navigate,
} from 'react-router-dom';

import './App.scss';
import { HomePage } from './HomePage';
import { TabsPage } from './TabsPage';

/*
import { RouteComponentProps } from 'react-router-dom';
type TabsPageProps = React.FC<RouteComponentProps<{ tabId: string }>>;
const TabsPage: TabsPageProps = ({ match }) => {...};
or
import { useParams } from 'react-router-dom';
const TabsPage = () => {
  const { tabId } = useParams<{ tabId: string }>();
  ...
};
*/

const App: React.FC = () => {
  return (
    <div className="App">
      <div className="container">
        <nav className="navbar is-white">
          <Link to="/" className="navbar-item">Home page</Link>
          <Link to="/tabs" className="navbar-item">Tabs page</Link>
        </nav>
      </div>

      <section className="section">
        <div className="container">
          <h1 className="title">Mate academy</h1>

          <div className="columns">
            <div className="column">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/tabs" element={<TabsPage />} />
                <Route
                  path="*"
                  element={
                    <p>Page not found</p>
                  }
                />
                <Route path="/home" element={<Navigate to="/" />} />
              </Routes>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
};

export default App;
