// WRITE TESTS HERE

describe('Page', () => {
  it('should be visitable', () => {
    cy.visit('/');
  });
});
