module.exports = require('@mate-academy/cypress-tools/plugins');
