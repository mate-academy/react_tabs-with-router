import '@mate-academy/cypress-tools/support';
