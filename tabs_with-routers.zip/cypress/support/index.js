require('@mate-academy/cypress-tools/support');
